﻿using Assignment_1.Question_2;
using Assignment_1.Qustion_1;

namespace Assignment_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Qustion 1
            //int[] numbers = { 5, 3, 8, 4, 2 };

            //ISorter<int> sorter = new BubbleSorter<int>();

            //Console.WriteLine("Before Sorting: " + string.Join(", ", numbers));
            //sorter.Sort(numbers);
            //Console.WriteLine("After Sorting: " + string.Join(", ", numbers));
            #endregion
            #region Question 2
            //var range = new Range<int>(5, 15);

            //Console.WriteLine(range.IsInRange(10));
            //Console.WriteLine(range.IsInRange(20));
            //Console.WriteLine(range.ToString()); 
            #endregion
        }
    }
}
