﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1.Qustion_1
{
     public interface ISorter<T> where T : IComparable<T>
     {
        void Sort(T[] array);
     }

}
