﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1.Question_2
{
    internal class Range<T> where T : IComparable<T>, INumber<T>
    {
        public T Max { get; set; }
        public T Min { get; set; }
        public T length { get; set; }
        public Range(T min, T max)
        {
            Max = max;
            Min = min;
            if (Min.CompareTo(Max) > 0)
                throw new ArgumentException("Min must be less than or equal to Max");
            length = Max - Min;
        }
        public bool IsInRange(T value)
        {
            if (value == null) return false;

            return value.CompareTo(Min) >= 0 && value.CompareTo(Max) <= 0;
        }

        public override string ToString()
        {
            return $"Range={length}";
        }

    }

}
